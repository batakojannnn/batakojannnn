# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '26a07816cfaa0d7e028aced0d99f2c26420590e6922d68dbec33cb8a67b05edb610b3facf4c30e0bb6b52249b1b4abd71fa777bc345327cbd2ce5ad0b2ebbb64'