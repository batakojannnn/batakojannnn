class PostImagesController < ApplicationController
  def new
  end

  def create
  end

  def index
  end

  def show
  end
end
